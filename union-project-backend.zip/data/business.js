const english_keys_translation = {
    "village": "গ্রাম",
    "ward": "ওয়ার্ড",
    "business_name": "ব্যবসার নাম",
    "owner_name": "মালিকের নাম",
    "mobile": "মোবাইল",
    "shop_number": "দোকান নং",
    "assessment_tax": "এসেসমেন্ট কর",
    "upo_tax": "ইউপি কর",
    "structure": "অবকাঠামো",
    "business_capital": "ব্যবসার মূলধন",
    "business_code": "ব্যবসা কোড",
    "business_type": "ব্যবসার ধরণ"
}
]